/* Copyright 2016
 * All rights reserved.
 *
 * This file is part of lpc1769_template.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 */

/**
 *
 *
 * NOTE: It's interesting to check behavior differences between standard and
 * tickless mode. Set @ref configUSE_TICKLESS_IDLE to 1, increment a counter
 * in @ref vApplicationTickHook and print the counter value every second
 * inside a task. In standard mode the counter will have a value around 1000.
 * In tickless mode, it will be around 25.
 *
 */

/** \addtogroup rtos_blink FreeRTOS blink example
 ** @{ */

/*==================[inclusions]=============================================*/

#include "main.h"

#include "FreeRTOSConfig.h"
#include "board.h"

#include "FreeRTOS.h"
#include "task.h"
#include "newlib_stubs.h"

#define TEST_UART LPC_UART3
#define INICIO 0
#define PULSADOR 1
#define VELOCIDAD 2
#define SETEO 1

void Set_UART_3 (void); // Prototipo de Set_UART_3
void Set_UART_2 (void); // Prototipo de Set_UART_2
char equipo;
static int pulsadorFlag;

static int a_state=INICIO,b_state=INICIO;

char tramaenv[4]={0xAA,0,0,0x55};
char tramarec[4];
int contador=0;
static int velocidad=0;

int TramaValida(char* trama){
	return (trama[0]==0xAA && trama[3]==0x55);
}
int error(void){
	if(CheckBatADC()<30)
		return 0x30;
	if(Gpio_Get(Motor)==1)
			return 0x40;
	if(Gpio_Get(Mantenimiento)==1)
		return 0x60;
}
void EquipoA (void *pvParameters)
{	switch(a_state){

	case INICIO:
		tramaenv[1]=0x01;
		_write(UART3,tramaenv,4);
		_read(UART2,tramarec,4);
		if(tramarec[1]= 0xFF)
			a_state=PULSADOR;
	break;

	case PULSADOR:
		if(pulsadorFlag){
			if(contador%2){//El pulsador incrementa al contasdor con cada pulsada
				tramaenv[1]=0x05;
				tramaenv[2]=velocidad;
				_write(UART3,tramaenv,4);
			}
			else{
				tramaenv[1]=0x80;
				_write(UART3,tramaenv,4);

			}
			pulsadorFlag=0;
		}
		_read(UART2,tramarec,4);
		if(tramarec[1]= 0x00){
			if(tramarec[2]==0x30 || tramarec[2]=0x60)
				vTaskDelay(1000/portTICK_PERIOD_MS)
		if(tramarec[2]==0x40 || tramarec[2]==0x50)
			a_state=INICIO;
		pulsadorFlag=1;}
		break;

	default:

		break;


	}
}
void EquipoB (void *pvParameters)
{	switch(b_state){

	case INICIO:
		_read(UART3,tramarec,4);
		if(TramaValida(tramarec)&&tramarec[1]==0x01){
			b_state=SETEO;
			tramaenv[1]=0xFF;
		}

		tramaenv[2]=error();
		_write(UART2,tramaenv,4);
	break;

	case SETEO:
		_read(UART3,tramarec,4);
		if(TramaValida(tramarec)){
			if(tramarec[1]==0x05){
				if(tramarec[2]==1||tramarec[2]==5||tramarec[2]==10||tramarec[2]==20){
				EnciendoMotor(trama[2]);
				tramaenv[1]=0xFF;
				}
				tramaenv[2]=0x50;
			}
			if(tramarec[1]==0x80){
				ApagoMotor();
				tramaenv[1]=0xFF;
			}
		}
		else
			tramaenv[1]=0x00;
			tramaenv[2]=error();

		_write(UART2,tramaenv,4);
		break;

	default:
		break;
 }
}
int main(void)
{

	Set_UART_3(); //Inicializo UART y FIFO
	Set_UART_2(); //Inicializo UART y FIFO
		if(equipo==A)
		xTaskCreate(EquipoA, ( signed portCHAR* )"Equipo A",configMINIMAL_STACK_SIZE,NULL,tskIDLE_PRIORITY+1,NULL );
	if(equipo==B)
		xTaskCreate(EquipoB,( signed portCHAR* )"Equipo B",configMINIMAL_STACK_SIZE,NULL,tskIDLE_PRIORITY+1,NULL );

	//Inicio el Scheduler
	vTaskStartScheduler();

	while(1);

}

void Set_UART_3 (void)
{
	SystemCoreClockUpdate();
	Board_Init();
	Chip_IOCON_PinMuxSet(LPC_IOCON,0,25,FUNC3); //TXD3
	Chip_IOCON_PinMuxSet(LPC_IOCON,0,26,FUNC3); //RXD3
	Chip_UART_Init(TEST_UART);
	Chip_UART_SetBaud(TEST_UART, 9600);
	Chip_UART_ConfigData(TEST_UART, UART_LCR_WLEN8 | UART_LCR_SBS_1BIT | UART_LCR_PARITY_DIS);
	// Cargo los parámetros en la estructura para la FIFO.
	// Por default: FIFO_DMAMode = DISABLE, FIFO_Level=UART_FIFO_TRGLEV0
	// FIFO_ResetRxBuf=ENABLE, FIFO_ResetTxBuf=ENABLE, FIFO_State=ENABLE
	Chip_UART_SetupFIFOS(TEST_UART, UART_FCR_FIFO_EN | UART_FCR_TRG_LEV0);
	// Habilito transmisión en pin TXD
	Chip_UART_TXEnable(TEST_UART);

}
void Set_UART_2 (void)
{
	SystemCoreClockUpdate();
	Board_Init();
	Chip_IOCON_PinMuxSet(LPC_IOCON,0,25,FUNC3); //TXD3
	Chip_IOCON_PinMuxSet(LPC_IOCON,0,26,FUNC3); //RXD3
	Chip_UART_Init(TEST_UART);
	Chip_UART_SetBaud(TEST_UART, 9600);
	Chip_UART_ConfigData(TEST_UART, UART_LCR_WLEN8 | UART_LCR_SBS_1BIT | UART_LCR_PARITY_DIS);
	// Cargo los parámetros en la estructura para la FIFO.
	// Por default: FIFO_DMAMode = DISABLE, FIFO_Level=UART_FIFO_TRGLEV0
	// FIFO_ResetRxBuf=ENABLE, FIFO_ResetTxBuf=ENABLE, FIFO_State=ENABLE
	Chip_UART_SetupFIFOS(TEST_UART, UART_FCR_FIFO_EN | UART_FCR_TRG_LEV0);
	// Habilito transmisión en pin TXD
	Chip_UART_TXEnable(TEST_UART);

}
